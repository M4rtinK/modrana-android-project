var Automatic = 0
var LockPortrait = 1
var LockLandscape = 2
var LockPrevious = 3