var Inactive = 0
var Activating = 1
var Active = 2
var Deactivating = 3
var foo = ".harmattan/"
function bar(){
    return ".harmattan/"
}
